# ThorTypeFilter.glyphsFilter
A Glyphs filter for creating interesting text effects
